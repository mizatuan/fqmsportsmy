<?php

include('connection.php');

//set the Malaysia zone
date_default_timezone_set("Asia/Singapore");

?>

<!DOCTYPE html>
<html>
<head>
    <title>KiddoCare Services</title>
    <link rel="stylesheet" type="text/css" href="style_user.css" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.css">
</head>

<body>

    <div class="wrapper">

        <div class="header">
            <img src="img/banner.jpg" width="100%" height="120%" alt="Avatar" class="avatar">
        </div>

        <div class="navigation">
            <a href="index.php">About</a>
            <a href="registration.php">Registration</a>
            <a href="registration_check.php">Registration Check</a>
            <a href="#">T&C</a>
            <a href="#">Contact</a>

            <div class="navigation-right">
                <a href="login.php"><i class="fa-regular fa-circle-user fa-2x"></i></a>
            </div>
        </div>

        <div class="content">
            <h2>Check your registration ID!</h2>
            <p>Please confirm your registration before you leave.</p>
            <br>

            <div style="display: inline-block;">
                <form action="" method="post">
                    <label>Child Name</label> 
                    <input type = "text" name="search_date" required>
                    <input type = "submit" name="btn_search" value="Search"> 
                </form>
            </div>

            <br><small style= "color: red;">* Click Search button to confirm your registration</small>
            <br><br>
			<?php

                //check if Search button is clicked or not
                if(isset($_POST['btn_search']))
                {
                    //if clicked, get the search value from the form and assign to variable
                    $search=$_POST['search_date'];

                    //create query to select record that match with the search value.
                    $sql_search="SELECT * FROM registration_info WHERE child_name='$search' AND (registraton_status ='Registered' OR registration_status = 'Cancel')";
     
                    //execute the query
                    $query = mysqli_query($conn, $sql_search);

                    //count the number of records available in booking_info table
                    $record=mysqli_num_rows($query);

            ?>
                    <table id="tbl_adminlist">
                        <tr>
							  <th>No.</th>
							  <th>Registration ID</th>
							  <th>Child Name</th>
							  <th>Child Gender</th>
							  <th>Child Birth Certificate No</th>
							  <th>Child Birthdate</th>
							  <th>Child Age</th>
							  <th>Parent Name</th>
							  <th>Parent Phone</th>
							  <th>Parent Address</th>
							  <th>Registration Status</th>
                        </tr>

            <?php
     
                    //check whether booking records found or not. 
                    if($record > 0)
                    {
                        echo "<p>Dates, centres, and times not available for registration.</p>";
                        //assign record running number start with 1
                        $no=1; 

                        //fetches a result row as an associative array
                        while($row = mysqli_fetch_assoc($query))
                        { 
            ?>
                        <tr>
                            <td align="center"><?php echo $no++."."; ?></td>
                            <td align="center"><?php echo $row['child_name']; ?></td>
                        </tr>
            <?php
                        }
                    }

                    else
                    {
            ?>          <br>
                        <tr>
                            <td colspan="5"><div>Registration for the searched name was not found.</div></td>
                        </tr>
            <?php
                    }
                }
            ?>
                    </table>

            <?php mysqli_close($conn); ?>

        </div>
  
        <div class="footer">
            <p style="padding-top: 1.3rem; font-weight: bold;">KiddoCare Services</p>
        </div>

    </div>

</body>
</html>
