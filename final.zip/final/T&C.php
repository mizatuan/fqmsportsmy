<!DOCTYPE html>
<html>
<head>
<title>KiddoCare Services</title>
<link rel="stylesheet" type="text/css" href="style_user.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.css">

</head>
<body>

    <!-- div wrapper -->
    <div class="wrapper">

        <!-- div header -->
        <div class="header">
            <img src="img/banner.jpg" width="100%" height="120%" alt="Avatar" class="avatar">
        </div>
        
        <!-- div left navigation -->
        <div class="navigation">
            <a href="index.php">About</a>
            <a href="registration.php">Registration</a>
            <a href="T&C.php">T&C</a>
            <a href="contact.php">Contact</a>

            <!-- div right navigation -->
            <div class="navigation-right">
                <a href="login.php"><i class="fa-regular fa-circle-user fa-2x"></i></a>
            </div>
        </div>

        <!-- div content -->
        <div class="content">
			
            <h2>1. Terms & Conditions</h2>
			
            <p>1.1) The Terms & Conditions below are a legal binding agreement between you as the Client and KiddoCare as the Service.</p>
				
			<p>1.2) ‘Client’ refers to the person/family using KiddoCare Services.</p>
				
			<p>1.3) ‘Candidates’ refers to any person that KiddoCare introduces to the Client. </p>
				
			<p>1.4) Posting false, incomplete, inaccurate or illegal information is strictly prohibited and may be punishable by law. </p>
				
				<br>
					
			<h2>2. Sitter Responsibilities</h2>
				
			<p>2.1) Uphold the highest level of safety and well-being of the children.</p>

            <p>2.2) Provide a nurturing and engaging environment.</p>

            <p>2.3) Supervise the children's activities at all times.</p>
			
			<p>2.4) Plan and prepare meals and/or bottles to feed children.</p>
			
			<p>2.5) Dress the children and/or change diapers.</p>
			
			<p>2.6) Place the children down for naps and/or bedtime.</p>


        </div>

        <!-- div footer -->
        <div class="footer">
            <p style="padding-top: 1.3rem; font-weight: bold;">KiddoCare Services</p>
        </div>

    </div>
    
</body>
</html>
