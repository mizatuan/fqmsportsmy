<?php 

  include('connection.php');
 

//include login-check.php file
include('login-check.php');

  //get booking id from delete link (URL) and assign to variable
  $registration_id = $_GET['id'];

  //create query to delete record from database that match with the id from delete link
  $sql_delete=  "DELETE FROM registration_info WHERE registration_id = $registration_id";

  //execute the query
  $query = mysqli_query($conn, $sql_delete);

  //to check whether query is executed or not
  if($query==TRUE)
  {
    //query executed
    echo "<script>alert('registration record deleted.')</script>";        
    header("Refresh: 0, url = registration_list.php");
    exit();
  }
  else
  {
    //if query failed to execute/error
    echo "<script>alert('Failed to delete registration.')</script>";
    header("Refresh: 0, url = registration_list.php");
    exit();
  } 

  //close the connection
  mysqli_close($conn);

?>

