<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php include("sidebar_menu.php"); ?>

<div class="main">
  <h2>Add New Admin</h2>
  <br>
  
   <form method="post" action="" enctype="multipart/form-data">

    <table id="tbl_full">
      <tr>
		  
		<tr>
        <td>Picture</td>
        <td><input type="file" name="image" accept="img/png, img/jpeg, img/jpg" required></td>
		</tr>

        <td>Name</td>
        <td><input type="text" name="fullname" size="40" required></td>
      </tr>

      <tr>
        <td>Email</td>
        <td><input type="email" name="email" size="40" required></td>
      </tr>

      <tr>
        <td>Username</td>
        <td><input type="text" name="username" size="40" required></td>
      </tr>

      <tr>
        <td>Password</td>
        <td><input type="password" name="password" size="40" required></td>
      </tr>

      <tr>
        <td colspan="2"><input type="submit" name="add_admin" value="Add Admin" required></td>
      </tr>
    </table>

  </form>

</div>

</body>
</html> 

<?php
  
//include connection.php file
include("connection.php");

//check if Add Admin button is clicked
if(isset($_POST['add_admin']))
{
  //get the value of admin name, admin email, admin username and password from form assign each values to PHP variable.
  $fullname=$_POST['fullname'];
  $email=$_POST['email'];
  $username=$_POST['username'];
  $password=md5($_POST['password']);
	
	//check whether the image selected or not and set the value for image name accordingly
  if(isset($_FILES['image']['name']))
  {
    //upload the image
    //to upload image, we need image name, source path and destination path


    //get the image name and store it in the PHP variable
    $image_name=$_FILES['image']['name'];


    //get the extension of the image
    $ext=end(explode('.', $image_name));


    //rename the image
    $image_name=$username.".".$ext;


    //image temporary location before upload to current destination 
    $source_path=$_FILES['image']['tmp_name'];


    //location to upload the image
    $destination_path="img/".$image_name;


    //finally upload the image
    $upload=move_uploaded_file($source_path, $destination_path);


    //check whether the image uploaded or not
    //if the image not uploaded, display the error message then stop the uploading process
    if($upload==FALSE)
    {
      //if image unsuccessfull upload
      echo "<script>alert('Error: Image cannot be uploaded!.')</script>"; 
      header("Refresh: 0, url = admin_insert.php");
      exit();
    }
  } 
  else
  {
    //do not upload the image and set the image value as blank
    $image_name="";
  }


  //create SQL INSERT INTO statement
  $sql_add="INSERT INTO admin (admin_name, admin_email, admin_username, admin_password, image) VALUES ('$fullname', '$email', '$username', '$password', '$image_name')";

  //execute the query
  $query=mysqli_query($conn, $sql_add);

  //check whether the query is executed or not
  if($query==TRUE)
  {
    //display success message if query is executed without error
    echo "<script> alert('New admin added') </script>";
    header("Refresh: 0, url=admin_list.php");
    exit();
  }
  else
  {
    //display error message if query is executed with error
    echo "<script> alert('Failed to add new admin') </script>";
    header("Refresh: 0, url=admin_list.php");
    exit();
  }
}

//close databse connection
mysqli_close($conn);

?>


