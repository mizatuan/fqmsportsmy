<!DOCTYPE html>
<html>
<head>
<title>KiddoCare Services</title>
<link rel="stylesheet" type="text/css" href="style_user.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.css">

</head>
<body>

    <!-- div wrapper -->
    <div class="wrapper">

        <!-- div header -->
        <div class="header">
            <img src="img/banner.jpg" width="100%" height="120%" alt="Avatar" class="avatar">
        </div>
        
        <!-- div left navigation -->
        <div class="navigation">
            <a href="index.php">About</a>
            <a href="registration.php">Registration</a>
            <a href="T&C.php">T&C</a>
            <a href="contact.php">Contact</a>

            <!-- div right navigation -->
            <div class="navigation-right">
                <a href="login.php"><i class="fa-regular fa-circle-user fa-2x"></i></a>
            </div>
        </div>

        <!-- div content -->
        <div class="content">

            <h2>About KiddoCare Sevices</h2>

            <p>KiddoCare is a leading provider of child care and early education services. Our mission is to create a nurturing and stimulating environment where children can learn, grow , and thrive. With a team of dedicated professionals and a curriculum that focuses on holistic development , we strive to provide the highest quality care and education for children of all ages. Also, with KiddoCare Services, you can find a babysitter or family to babysit for in your area. You can easily contact them and make further arrangements. It’s up to you to decide what kind of carer or family is best for you, so you can make your own decisions about who to contact. Whether you’re working from home, or at the office, or you’re a homemaker needing a few hours break for yourself, you can be rest assured of your children being in caring, trustworthy hands. In addition, our babysitters are Malaysian women trained by childcare industry experts.</p>


        </div>

        <!-- div footer -->
        <div class="footer">
            <p style="padding-top: 1.3rem; font-weight: bold;">KiddoCare Services</p>
        </div>

    </div>
    
</body>
</html>
