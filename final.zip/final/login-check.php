<?php 


    include ("connection.php");
 
    //check whether admin username session is set or not
    if(isset($_SESSION['id']) AND isset($_SESSION['name']))
    {
		
		//display admin picture
		echo "<center><img src=".$_SESSION['image']." width='65px'"." height='80px'>"."</img></center><br>";

      //display admin name
      echo "<center>Admin<br>[".ucwords($_SESSION['name'])."]</center>";
    }
    else
    {
      //if not login, create not-login session variable to assign error message
      $_SESSION['not-login'] = "<div class='error'>Please log in to access Admin Panel.</div>";


      //redirect to page Login 
      header("location: login.php");
    }


?>
