<?php 

//include connection.php file
include('connection.php');

//get the admin id (Primary Key) from the delete link
$admin_id=$_GET['id'];

//create SQL DELETE query to delete admin record that match with the admin id.
$sql_delete="DELETE FROM admin WHERE admin_id=$admin_id";

//execute the query
$query=mysqli_query($conn, $sql_delete);

//check if query executed or not
if($query==TRUE)
{
  //record deleted and display success message
  echo "<script> alert('Admin deleted') </script>";
  header("Refresh: 0,  url=admin_list.php");
  exit();
}
else
{
  //record not deleted and display error message
  echo "<script> alert('Failed to delete Admin') </script>";
  header("Refresh: 0,  url=admin_list.php");
  exit();
}

//close database connection
mysqli_close($conn);
?>