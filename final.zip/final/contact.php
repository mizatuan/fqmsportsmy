<!DOCTYPE html>
<html>
<head>
<title>KiddoCare Services</title>
<link rel="stylesheet" type="text/css" href="style_user.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.css">

</head>
<body>

    <!-- div wrapper -->
    <div class="wrapper">

        <!-- div header -->
        <div class="header">
            <img src="img/banner.jpg" width="100%" height="120%" alt="Avatar" class="avatar">
        </div>
        
        <!-- div left navigation -->
        <div class="navigation">
            <a href="index.php">About</a>
            <a href="registration.php">Registration</a>
            <a href="T&C.php">T&C</a>
            <a href="contact.php">Contact</a>

            <!-- div right navigation -->
            <div class="navigation-right">
                <a href="login.php"><i class="fa-regular fa-circle-user fa-2x"></i></a>
            </div>
        </div>

        <!-- div content -->
        <div class="content">
			
			<center>
            <h2>Contact Us At</h2>
			<br>
			<h4>Company Location</h4>

            <p>11A, Jalan Yeoh Khuan Joo, Taman Fair Baharu, 31400, Ipoh, Perak.</p>
			
			<h4>Company Phone</h4>

            <p>010-020-0340</p>
			
			<h4>Office Location</h4>

            <p>Taman Fair Baharu</p>
			
			<h4>Office Hours</h4>

            <p>07:30 AM - 9:30 PM Daily</p>
			
			<h4>Company Email</h4>

            <p>KiddoCareServices@gmail.com</p>
			</center>
			
        </div>

        <!-- div footer -->
        <div class="footer">
            <p style="padding-top: 1.3rem; font-weight: bold;">KiddoCare Services</p>
        </div>

    </div>
    
</body>
</html>
