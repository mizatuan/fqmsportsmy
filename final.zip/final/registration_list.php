<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php include("sidebar_menu.php"); ?>

<div class="main">
  <h2>List of Registrations</h2>
  <br>
	
	<div style="display: inline-block;">
      <form action="" method="post">
        <label>Search</label> 
        <input type = "text" name="search_id" size="20" placeholder="Search by Registration ID">
        <input type = "submit" name="btn_search" value="Search">
      </form>
  </div>
  <br><br>

  <table id="tbl_adminlist">
    <tr>
      <th>No.</th>
      <th>Registration ID</th>
      <th>Child Name</th>
      <th>Child Gender</th>
      <th>Child Birth Certificate No</th>
      <th>Child Birthdate</th>
	  <th>Child Age</th>
	  <th>Parent Name</th>
	  <th>Parent Phone</th>
	  <th>Parent Address</th>
      <th>Registration Status</th>
      <th>Action</th>
    </tr>
    
    <?php

      include ("connection.php");
//check if Search button is clicked or not
      if(isset($_POST['btn_search']))
      {
        //if clicked, get the search value from the form and assign to variable
        $search=$_POST['search_id'];

        //create query to select record that match with the search value.
        $sql_select="SELECT * FROM registration_info WHERE registration_id=$search";
      }
      else 
      {
       //check if Search button is clicked or not
      if(isset($_POST['btn_search']))
      {
        //if clicked, get the search value from the form and assign to variable
        $search=$_POST['search_id'];

        //create query to select record that match with the search value.
        $sql_select="SELECT * FROM registration_info WHERE registration_id=$search";
      }
      else 
      {
        //if Search button is not clicked, then create select query to display all booking records in descending order based on booking date
        $sql_select="SELECT * FROM registration_info";

      }

      }

      //execute the query
      $query = mysqli_query($conn, $sql_select);

      //count the number of records available in booking_info table
      $record=mysqli_num_rows($query);
     
      //check whether booking records found or not
      if($record > 0)
      {
        //if record found

        $no=1; //assign record running number start with 1

        //fetches a result row as an associative array
        while($row = mysqli_fetch_assoc($query))
        { 
    ?>
          <tr>
            <td align="center"><?php echo $no++."."; ?></td>
            <td align="center"><?php echo $row['registration_id']; ?></td>
            <td><?php echo $row['child_name']; ?></td>
            <td><?php echo $row['child_gender']; ?></td>
            <td align="center"><?php echo $row['child_birth_cert']; ?></td>
            <td align="center"><?php echo $row['child_birthdate']; ?></td>
            <td align="center"><?php echo $row['child_age']; ?></td>
            <td align="center"><?php echo $row['parent_name']; ?></td>
			<td align="center"><?php echo $row['parent_phone']; ?></td>
			<td align="center"><?php echo $row['parent_address']; ?></td>
			<td align="center"><?php echo $row['registration_status']; ?></td>
            <td align="center">
              <a href="registration_update.php?id=<?php echo $row['registration_id']; ?>">
                <button>Update</button></a> 
              <a href="registration_delete.php?id=<?php echo $row['registration_id']; ?>">
                <button> Delete</button></a>
            </td>
          </tr>
    <?php
        }
      }
      else
      {
    ?>
        <tr>
          <td colspan="10"><div>Registration record not found</div></td>
        </tr>
    <?php
      }
      
      mysqli_close($conn);
    ?>

  </table>

</div>

</body>
</html>