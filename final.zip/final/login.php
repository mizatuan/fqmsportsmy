<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="login.css">
</head>

<body>

  <center><h2 style="margin-top: 8%;">Log In</h2></center>
	
	<form action="" method="post">


    <div class="imgcontainer">
      <img src="img/admin_icon.png" alt="Avatar" class="avatar">
		
		<?php 
      
      //call database connection file.
      include("connection.php");


      //check whether not-login session variable is set or not
      if(isset($_SESSION['not-login'])) 
      {
        //if set, display not-login session message 
        echo $_SESSION['not-login']; 


        //clearing out the not-login session data so when the page is refreshed, the value is null
        unset($_SESSION['not-login']);
      }


?>

    </div>


    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>


      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>
        
      <button type="submit" name="login">Login</button>
    </div>


		
		<?php 


//call database connection file
include('connection.php');


//check whether Login button is clicked or not
if(isset($_POST['login']))
{
  //if clicked, get the value from login form and stored in PHP variables
  $username = $_POST['username'];
  $password = md5($_POST['password']);


  //create query to select record that match with the posted username and password
  $sql_select = "SELECT * FROM admin 
                WHERE admin_username='$username' 
                AND admin_password='$password'";


  //execute the query
  $query = mysqli_query($conn, $sql_select);


  //count the matched records 
  $record = mysqli_num_rows($query);

	
	

  //check whether record is found or not
  if($record == 1)
  {
    //if found, fetch the matched record and store in associative array
    $row = mysqli_fetch_assoc($query);


    //create session variable and assign it with the value from admin table
    $_SESSION['id'] = $row['admin_id']; 
    $_SESSION['name'] = $row['admin_name']; 
	  

	  //set the image path - folder and image filename
	  $image_path = "img/".$row['image'];


	  //create session variable and assign it with the image path
	  $_SESSION['image'] = $image_path;



    //redirect to admin_index.php page  
    header("location: admin_index.php");
  }
  else 
  {
    //if record not found, create not-login session variable to assign error message
    $_SESSION['not-login'] = "<div class='error'>Username or password did not match.</div>";


    //redirect to login.php page       
    header("location: login.php");
  } 
}


//close database connection
mysqli_close($conn);


?>

</form>


</body>
</html>


  