<?php

include('connection.php');

//to set the time zone
date_default_timezone_set("Asia/Singapore"); 

//if Booking button is clicked
if(isset($_POST['add_registration']))
{
        //get the values from the form
        $child_name = $_POST['child_name'];
        $child_gender = $_POST['child_gender'];
        $child_birth_cert = $_POST['child_birth_cert'];
        $child_birthdate = $_POST['child_birthdate'];
        $child_age=$_POST['child_age'];
        $parent_name = $_POST['parent_name'];
		$parent_phone = $_POST['parent_phone'];
		$parent_address = $_POST['parent_address'];
    
    //set the registration status to "Registered"
    $status="Registered";
	
            //if record not found, create insert query
            $sql_insert="INSERT INTO registration_info (child_name, child_gender, child_birth_cert, child_birthdate, child_age, parent_name, parent_phone, parent_address, registration_status) VALUES ('$child_name', '$child_gender', '$child_birth_cert', '$child_birthdate', $child_age, '$parent_name', '$parent_phone', '$parent_address', '$status')";
	
            //execute the query
            $query_insert=mysqli_query($conn, $sql_insert);

            //check whether query is execute or not
            if($query_insert==TRUE)
            {
                //if query successful executed
                echo "<script>alert('Thank you for your registration!.')</script>"; 
                header("Refresh: 0, url = registration.php");
                exit();
            }
            else
            {
                //if query failed to execute
                echo "<script>alert('Registration failed')</script>";
                header("Refresh: 0, url = registration.php");
                exit();
            } 
        
    }
    //close the connection
    mysqli_close($conn);

?>

<!DOCTYPE html>
<html>
<head>
<title>KiddoCare Services</title>
<link rel="stylesheet" type="text/css" href="style_user.css" />
<link rel="stylesheet" type="text/css" href="style.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.css">

</head>
<body>

    <div class="wrapper">

        <div class="header">
            <img src="img/banner.jpg" width="100%" height="120%" alt="Avatar" class="avatar">
        </div>
        
        <div class="navigation">
            <a href="index.php">About</a>
            <a href="registration.php">Registration</a>
            <a href="T&C.php">T&C</a>
            <a href="contact.php">Contact</a>

            <div class="navigation-right">
                <a href="login.php"><i class="fa-regular fa-circle-user fa-2x"></i></a>
            </div> 
        </div>

        <div class="content">
            <h2>Register your kiddo here!</h2>
            <p>Please read terms and conditions before register.</p>
            <br>

            <form action="" method="post">
                <table id="tbl_full">
					
					 <tr>
                        <td>Child Name</td>
                        <td>
                            <input type="text" name="child_name" size="50" value="" required>
                        </td>
                    </tr>
					
					<tr>
                        <td>Child Gender</td>
                        <td>
                            <input type="radio" name="child_gender" value="Male" required>Male
							<input type="radio" name="child_gender" value="Female" required>Female
                        </td>
                    </tr>
					
					 <tr>
                        <td>Child Birth Certificate No.</td>
                        <td>
                            <input type="text" name="child_birth_cert" size="50" value="" required>
                        </td>
                    </tr>
					
					<tr>
                        <td>Child Birth Date</td>
                        <td>
                            <input type="date" name="child_birthdate" value="" required>
                        </td>
                    </tr>
					
                    <tr>
                        <td>Child Age</td>
                        <td>
                            <input type="number" name="child_age" min="3" max="6" required>
                        </td>
                    </tr>

                    <tr>
                        <td>Parent Name</td>
                        <td>
                            <input type="text" name="parent_name" size="50" placeholder="Enter name" value="" required>
                        </td>
                    </tr>
					
					 <tr>
                        <td>Parent Phone</td>
                        <td>
                            <input type="text" name="parent_phone" size="50" placeholder="Enter phone number" value="" required>
                        </td>
                    </tr>

                    <tr>
                        <td>Parent Address</td>
                        <td>
                            <textarea name="parent_address" cols="47" rows="7"></textarea>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2"><input type="submit" name="add_registration" value="Register"></td>
                    </tr>
                </table>
            </form>
        </div>

        <div class="footer">
            <p style="padding-top: 1.3rem; font-weight: bold;">KiddoCare Services</p>
        </div>

    </div>

</body>
</html>
