<?php

if(!isset($_SESSION))
{
	//start session
session_start();

}

$host="localhost";
$user="root";
$pass="";
$dbname="registration";
$conn=mysqli_connect ($host, $user, $pass, $dbname) or die ("Error: " . mysqli_connect_error ());

?>