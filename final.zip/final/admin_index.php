<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php 
include("sidebar_menu.php");
include('connection.php');
?>
<div class="main">
  <h2>Dashboard</h2>
  <br>
  
  <h2>Registration Summary as at <?php echo date("d/m/Y"); ?></h2>
  
  <div class="col-dashboard">

    <?php 

      //create SELECT query from booking_info table
      $sql_registration="SELECT * FROM registration_info";

      //execute the query
      $registration=mysqli_query($conn, $sql_registration);

      //calculate the number of booking records
      $count_registration=mysqli_num_rows($registration);

    ?>
    
    <h1>
      <?php 
        //display the number of booking in booking_info table
        echo $count_registration; 
      ?>
    </h1>
    <h3>Registration</h3>

  </div>
  
  <div class="col-dashboard">

    <?php 

      //create SELECT query from booking_info table where status is 'Booked' 
      $sql_registered="SELECT * FROM registration_info WHERE registration_status = 'Registered'";

      //execute the query
      $registered=mysqli_query($conn, $sql_registered);

      //calculate the number of Booked status booking
      $count_registered=mysqli_num_rows($registered);

    ?>
    
    <h1>
      <?php 
            //display the number of Booked status records
            echo $count_registered; 
      ?>
    </h1>
    <h3>Registered Status</h3>

  </div>

<div class="col-dashboard">

    <?php 

      //create SELECT query from booking_info table where status is Cancel
      $sql_cancel="SELECT * FROM registration_info WHERE registration_status ='Cancel'";

      //execute the query
      $cancel=mysqli_query($conn, $sql_cancel);

      //calculate the number of Cancel booking
      $count_cancel=mysqli_num_rows($cancel);

    ?>
    
    <h1>
      <?php 
        //display the number of cancel booking
        echo $count_cancel; 
      ?>
    </h1>
    <h3>Cancel Status</h3>

  </div>
  
  <div style="padding-top:18%"><h2>Admin Summary as at <?php echo date("d/m/Y"); ?></h2></div>
  <div class="col-dashboard">

    <?php 

      //create SELECT query from admin table 
      $sql_admin="SELECT * FROM admin";

      //execute the query
      $admin=mysqli_query($conn, $sql_admin);

      //calculate the number of admin in admin table
      $count_admin=mysqli_num_rows($admin);

    ?>

    <h1>
      <?php 
        //display the number of admin
        echo $count_admin; 
      ?>
    </h1>
    <h3>Admin</h3>

  </div>


</div>

</body>
</html> 
