<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php include("sidebar_menu.php"); ?>

<div class="main">
  <h2>Update Admin</h2>
  <br>
</div>

</body>
</html> 
