<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php include("sidebar_menu.php"); ?>

<div class="main">
  <h2>List of Admin</h2>
  <br>
  <button onclick="window.location.href='admin_insert.php'">New Admin </button>
  
  <div style="display: inline-block; padding-inline: 30px;">
    <form method="post" action="">
      <label>Search</label>
      <input type="text" name="search_email" size="40" placeholder="Search by email">
      <input type="submit" name="btn_search" value="Search">
    </form>
  </div>
  <br><br>
  
  <table id="tbl_adminlist">
  <tr>
      <th>No.</th>
      <th>Name</th>
	  <th>Picture</th>
      <th>Email</th>    
	  <th>Action</th>
    </tr>
    
   <?php

  //include connection.php 
  include('connection.php');

	//check if search button is clicked or not
  if(isset($_POST['btn_search']))
  {
    //get the searched email and store the value in variabla $search
    $search=$_POST['search_email'];

    //create SQL search query using SELECT statement that match with the email
    $sql_select="SELECT * FROM admin WHERE admin_email LIKE '%$search%'";
  }
  else
  {
    //is search button is not clicked
    ////create SQL query using SELECT statement to view all records from admin table
    $sql_select="SELECT * FROM admin";
  }

  //execute the query
  $query=mysqli_query($conn, $sql_select);

  //count how many admin records found in the admin table
  $record=mysqli_num_rows($query);

  //check if admin records found.
  if($record>0)
  {
    //if admin records found
    //initialize records running number
    $no=1;

    //fetch the admin records row by row and store in variable $row as associative array
    while($row=mysqli_fetch_assoc($query))
    {
    ?>
      <tr>
        <td align="center"><?php echo $no++."."; ?></td>
        <td><?php echo $row['admin_name']; ?></td>
		<td><img src="img/<?php echo $row['image']; ?>" width="100px"></td>
        <td><?php echo $row['admin_email']; ?></td>
        <td align="center">
   		<a href="admin_delete.php?id=<?php echo $row['admin_id']; ?>&image_name=<?php echo $row['image']; ?>"><button>Delete</button></td></a>
      </tr>
    <?php
    }
  }
  else
  {
	//display error message if record not found
    ?>
    <tr>
      <td colspan="4"><div>Admin record not found.</div></td>
    </tr>
  <?php
  }
  mysqli_close($conn);

  ?>

  </table>

</div>

</body>
</html> 
