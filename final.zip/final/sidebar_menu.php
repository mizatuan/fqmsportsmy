<div class="sidenav">
	
	<style>
  .success {
  color: #FF9933;
  font-size: 1rem;
  font-weight: bold;
  padding: 0 0 40px 0;
}
</style>
	
	<div class="success"><?php include("login-check.php"); ?></div>

  <a href="admin_index.php">Dashboard</a>
  <a href="registration_list.php">Manage Registration</a>
  <a href="admin_list.php">Manage Admin</a>
  <a href="logout.php">Logout</a>
</div>

