<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php include("sidebar_menu.php"); ?>

<div class="main">
  <h2>Update Registration</h2>
  <br>
  
  <?php

    include('connection.php');

    //get booking id from update link (URL)
    $registration_id = $_GET['id'];

    //create query to select record from database that match with the id from update link
    $sql_select =  "SELECT * FROM registration_info WHERE registration_id = $registration_id";
    //execute the query
    $query_select = mysqli_query($conn, $sql_select);

    //count the number of records found in booking_info table that match to the booking id
    $record=mysqli_num_rows($query_select);

    //check whether booking record is found or not
    if($record == 1)
    {
      //fetches a result row as an associative array if record found
      $row = mysqli_fetch_assoc($query_select);

      //get individual booking record values from booking table and assign the value to PHP variable
      $registration_id=$row['registration_id'];
      $child_name = $row['child_name'];
	  $child_gender = $row['child_gender'];
	  $child_birth_cert = $row['child_birth_cert'];
	  $child_birthdate = $row['child_birthdate'];
	  $child_age = $row['child_age'];
      $parent_name = $row['parent_name'];
      $parent_phone = $row['parent_phone'];
      $parent_address=$row['parent_address'];
      $registration_status = $row['registration_status'];
    }
    else
    {
      //if record not found
      echo "<script>alert('Registration record not found')</script>";        
      header("Refresh: 0, url = admin_list.php");
      exit();
    }

  ?>

  
  <form action="" method="post">
    <table id="tbl_full">

      <tr>
        <td>Registration ID</td>
        <td>
          <input type="text" name="registration_id" size="10" value = "<?php echo $registration_id; ?>" readonly>
        </td>
      </tr>

      <tr>
        <td>Child Name</td>
        <td>
          <input type="text" name="child_name" size="40" value = "<?php echo $child_name; ?>" required>
        </td>
      </tr>
		
		<tr>
        <td>Child Gender</td>
        <td>
          <input type="text" name="child_gender" size="40" value = "<?php echo $child_gender; ?>" required>
        </td>
      </tr>
		
		<tr>
        <td>Child Birth Certificate No.</td>
        <td>
          <input type="text" name="child_birth_cert" size="40" value = "<?php echo $child_birth_cert; ?>" required>
        </td>
      </tr>

      <tr>
        <td>Child Birthdate</td>
        <td>
          <input type="date" name="child_birthdate" size="40" value = "<?php echo $child_birthdate; ?>" required>
        </td>
      </tr>

      <tr>
        <td>Child Age</td>
        <td>
          <input type="text" name="child_age" size="40" value = "<?php echo $child_age; ?>" readonly>
        </td>
      </tr>

     <tr>
        <td>Parent Name</td>
        <td>
          <input type="text" name="parent_name" size="40" value = "<?php echo $parent_name; ?>" required>
        </td>
      </tr>

      <tr>
        <td>Parent Phone</td>
        <td>
          <input type="text" name="parent_phone" size="40" value = "<?php echo $parent_phone; ?>" required>
        </td>
      </tr>

      <tr>
        <td>Parent Address</td>
        <td>
          <input type="text" name="parent_address" size="40" value = "<?php echo $parent_address; ?>" required>
        </td>
      </tr>

      <tr>
        <td>Registration Status</td>
        <td>
          <select name="registration_status" required>
            <option <?php if($registration_status=="Registered") echo "selected"; ?> value="Registered">
              Registered
            </option>
            <option <?php if($registration_status=="Cancel") echo "selected"; ?> value="Cancel">
              Cancel
            </option>
          </select>
        </td>
      </tr>

      <tr>
        <td colspan="2"><input type="submit" name="update_registration" value="Update Registration"></td>
      </tr>

    </table>
  </form>

</div>

</body>
</html> 

<?php

//if Update button clicked
if(isset($_POST['update_registration']))
{
  //get values from the form and assign to PHP variable
  $registration_id= $_POST['registration_id'];
  $child_name = $_POST['child_name'];
  $child_gender = $_POST['child_gender'];
  $child_birth_cert = $_POST['child_birth_cert'];
  $child_birthdate=$_POST['child_birthdate'];
  $child_age = $_POST['child_age'];
  $parent_name=$_POST['parent_name'];
  $parent_phone = $_POST['parent_phone'];
  $parent_address=$_POST['parent_address'];
  $registration_status = $_POST['registration_status'];
  
  //create update query
  $sql_update="UPDATE registration_info 
              SET child_name='$child_name', 
              child_gender='$child_gender', 
              child_birth_cert='$child_birth_cert',
			  child_birthdate='$child_birthdate',
			  child_age='$child_age',
              parent_name='$parent_name', 
              parent_phone='$parent_phone', 
              parent_address='$parent_address', 
              registration_status='$registration_status'
              WHERE registration_id=$registration_id";

  //execute the query
  $query_update=mysqli_query($conn, $sql_update);

  if($query_update==TRUE)
  {
    //if query successful executed
    echo "<script>alert('Registration record updated')</script>";    
    header("Refresh: 0, url = registration_list.php");
    exit();
  }
  else
  {
    //if query failed to execute
    echo "<script>alert('Failed to update Registration record')</script>";
    header("Refresh: 0, url = registration_list.php");
    exit();
  }

  //close the connection
  mysqli_close($conn); 

}

?>