<?php


	include("connection.php");


	//destroy the all sessions
	session_destroy(); 


	//redirect to Login page
	header("location: login.php");
?>
